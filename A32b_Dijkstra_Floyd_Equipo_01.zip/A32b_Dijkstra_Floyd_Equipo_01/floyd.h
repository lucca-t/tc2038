#ifndef FLOYD_H
#define FLOYD_H

#include <iostream>
#include <vector>

using namespace std;

#ifndef INF
#define INF 1000000000
#endif

// Algoritmo de Floyd-Warshall:
// Tiempo: O(N^3), Espacio: O(N^2)
inline void floydWarshall(int n, const vector<vector<int>>& graph) {
    vector<vector<int>> dist(n, vector<int>(n, INF));
    
    // Inicialización de matriz de distancias
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (i == j) {
                dist[i][j] = 0;
            } else if (graph[i][j] != -1) {
                dist[i][j] = graph[i][j];
            }
        }
    }
    
    // Programación dinámica de Floyd-Warshall
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (dist[i][k] != INF && dist[k][j] != INF) {
                    if (dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }
    }
    
    // Impresión de matriz resultante
    cout << "\nFloyd:\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int val = (dist[i][j] == INF) ? -1 : dist[i][j];
            cout << val << (j == n - 1 ? "" : " ");
        }
        cout << "\n";
    }
}

#endif