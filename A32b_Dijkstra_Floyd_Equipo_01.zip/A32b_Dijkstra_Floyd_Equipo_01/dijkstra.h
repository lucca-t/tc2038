#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#ifndef INF
#define INF 1000000000
#endif

// Algoritmo de Dijkstra:
// Tiempo: O(N^3 log N) [o O(N^3) sobre matriz de adyacencia], Espacio : O(N) 
inline void dijkstraAllPairs(int n, const vector<vector<int>>& graph) {
    cout << "Dijkstra:\n";
    for (int src = 0; src < n; ++src) {
        vector<int> dist(n, INF);
        dist[src] = 0;
        
        // Min-heap de pares (distancia_acumulada, nodo_actual)
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        pq.push({0, src});
        
        while (!pq.empty()) {
            pair<int, int> current = pq.top();
            pq.pop();
            
            int d = current.first;
            int u = current.second;
            
            if (d > dist[u]) continue;
            
            for (int v = 0; v < n; ++v) {
                if (graph[u][v] != -1) { // Existe arista de u a v
                    int weight = graph[u][v];
                    if (dist[u] + weight < dist[v]) {
                        dist[v] = dist[u] + weight;
                        pq.push({dist[v], v});
                    }
                }
            }
        }
        
        // Impresión de distancias desde el origen actual
        for (int dst = 0; dst < n; ++dst) {
            if (src != dst) {
                int val = (dist[dst] == INF) ? -1 : dist[dst];
                cout << "node " << (src + 1) << " to node " << (dst + 1) << ":  " << val << "\n";
            }
        }
    }
}

#endif